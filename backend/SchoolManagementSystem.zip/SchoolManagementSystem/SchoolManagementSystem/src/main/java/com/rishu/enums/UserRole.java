package com.rishu.enums;

public enum UserRole {

    ADMIN,

    STUDENT
}
